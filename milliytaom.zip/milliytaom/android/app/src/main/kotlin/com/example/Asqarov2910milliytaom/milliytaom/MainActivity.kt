package com.example.Asqarov2910milliytaom.milliytaom

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
